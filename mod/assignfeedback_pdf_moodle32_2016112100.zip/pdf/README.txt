This is part of the PDF annotation plugin for Moodle assignments.

Full instructions and information can be found in the submission part of this assignment at:
https://moodle.org/plugins/view.php?plugin=assignsubmission_pdf
OR
https://github.com/davosmith/moodle-assignsubmission_pdf

==Recent changes==

* 2016-11-21 - Minor M3.2 compatibility fix (only behat affected)
* 2016-05-20 - Fix behat tests for Moodle 3.1 compatibility
* 2015-11-08 - Minor fix to behat tests
* 2014-05-07 - Small change to possibly improve PDF compatibility in some situations
* 2014-04-02 - Allow response files to be deleted
* 2013-10-30 - Fix: support for resubmissions
* 2013-10-15 - Moodle 2.6 compatibility fix
* 2013-10-04 - Fix: capabilities typo, grading order with 'separate groups', minor language string issue, blind marking support + better team submission support
* 2013-06-10 - Fix minor issue with 'find comments' menu, fix feedback not being displayed to students when no grade given
* 2013-05-31 - Fix deleting items from the quicklist, fix support for team submissions
* 2013-05-30 - Converted YUI2 buttons to YUI3, various styling fixes
* 2013-03-25 - Plugin is disabled if the ghostscipt path is incorrect
* 2013-03-06 - Removed the MooTools library, switching to YUI instead
* 2013-02-13 - Fixed the positioning of the context menu
